package com.vinayak.project.uber.uberApp.entities.enums;

public enum RideRequestStatus {
    PENDING,CANCELLED,CONFIRMED
}
