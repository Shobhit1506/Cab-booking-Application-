package com.vinayak.project.uber.uberApp.dto;

import lombok.Data;

@Data
public class OnBoardDriverDto {
    private String vehicleId;
}
