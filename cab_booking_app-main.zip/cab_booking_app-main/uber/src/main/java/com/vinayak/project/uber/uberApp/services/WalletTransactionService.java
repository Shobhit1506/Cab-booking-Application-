package com.vinayak.project.uber.uberApp.services;

import com.vinayak.project.uber.uberApp.entities.WalletTransaction;

public interface WalletTransactionService {
     void createNewWalletTransaction(WalletTransaction walletTransaction);

}
