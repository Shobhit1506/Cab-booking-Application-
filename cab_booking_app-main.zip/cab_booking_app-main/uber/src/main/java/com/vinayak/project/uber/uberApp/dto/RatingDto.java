package com.vinayak.project.uber.uberApp.dto;

import lombok.Data;

@Data
public class RatingDto {
    private Long rideId;
    private Integer rating;
}
