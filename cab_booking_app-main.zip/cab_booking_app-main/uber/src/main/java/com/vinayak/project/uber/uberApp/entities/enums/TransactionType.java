package com.vinayak.project.uber.uberApp.entities.enums;

public enum TransactionType {

    DEBIT,CREDIT
}
